
#include "BBT.c"

int main()
{

    //Tabuleiro
    tabuleiro();

    return 0;
}